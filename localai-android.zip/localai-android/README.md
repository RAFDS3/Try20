# Local AI (Android)
Asisten lokal yang membuka aplikasi Android dari perintah teks dan belajar sendiri dari feedback & kebiasaanmu. Tanpa internet.

## Build
Push ke GitHub -> tab Actions -> "Build APK" -> unduh artifact `LocalAI-debug-apk`.

## Cara belajar
- Perintah dicocokkan ke nama aplikasi + bobot kata yang dipelajari.
- Tekan "Benar"/"Salah" atau pilih manual -> bobot kata->aplikasi diperbarui (mis. "wa" -> WhatsApp).
- Kebiasaan per jam disimpan untuk saran aplikasi. Semua data di SharedPreferences lokal.
