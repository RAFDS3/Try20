# Local AI v2 (Android, Helio G99 Ultra)
Asisten lokal yang membuka aplikasi dari perintah teks dan belajar sendiri. Tanpa internet.

## Build
Push ke GitHub -> Actions -> "Build APK" -> unduh artifact `LocalAI-debug-apk`.

## Otak hibrida
1. Heuristik + bobot kata->app (belajar instan dari feedback Benar/Salah).
2. Deep learning (MLP): hash fitur(kata+trigram+jam) -> 64 -> 64 -> softmax app.
   Online learning (backprop SGD) + experience replay, ditulis C++ dengan NEON.

## Optimasi Helio G99 Ultra (2xA76 + 6xA55, Mali-G57 MC2)
- Kernel dot/axpy NEON FMA, compile `-mcpu=cortex-a76 -O3`.
- Thread training dipin ke core big (A76) via `sched_setaffinity`; core kecil tetap hemat daya.
- Model kecil (~88 ribu parameter, ~350 KB) dan training singkat -> tidak membuat HP panas.
- ABI arm64-v8a saja (+x86_64 untuk emulator) agar APK kecil.
