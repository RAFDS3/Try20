#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
// MLP kecil dengan online learning (backprop SGD) di perangkat.
// Arsitektur: sparse input (hash fitur) -> Embedding-sum(64) -> ReLU
//             -> Dense(64) -> ReLU -> Dense(OUT) -> Softmax
// Operasi dot/axpy dioptimalkan NEON (aarch64: Cortex-A76/A55 pada Helio G99).
#include <vector>
#include <cmath>
#include <mutex>
#include <random>
#include <algorithm>
#include <string>
#include <sched.h>
#if defined(__aarch64__) && defined(__ARM_NEON)
#include <arm_neon.h>
#define NN_NEON 1
#endif
#ifndef NN_TEST
#include <jni.h>
#endif

namespace {
constexpr int V = 1024 + 24;     // 1024 hash fitur + 24 jam
constexpr int H1 = 64, H2 = 64;
constexpr int OUT = 256;

std::vector<float> E, b1, W2, b2, W3, b3;
std::mutex mu;

inline float dotp(const float* a, const float* b, int n) {
#ifdef NN_NEON
    float32x4_t acc = vdupq_n_f32(0.f);
    int i = 0;
    for (; i + 4 <= n; i += 4) acc = vfmaq_f32(acc, vld1q_f32(a + i), vld1q_f32(b + i));
    float s = vaddvq_f32(acc);
    for (; i < n; ++i) s += a[i] * b[i];
    return s;
#else
    float s = 0.f;
    for (int i = 0; i < n; ++i) s += a[i] * b[i];
    return s;
#endif
}

// y += a * x
inline void axpy(float* y, float a, const float* x, int n) {
#ifdef NN_NEON
    float32x4_t va = vdupq_n_f32(a);
    int i = 0;
    for (; i + 4 <= n; i += 4) vst1q_f32(y + i, vfmaq_f32(vld1q_f32(y + i), va, vld1q_f32(x + i)));
    for (; i < n; ++i) y[i] += a * x[i];
#else
    for (int i = 0; i < n; ++i) y[i] += a * x[i];
#endif
}

struct Act { float h1[H1], h2[H2], p[OUT]; float scale; };

void forward(const int* f, int n, int nActive, Act& a) {
    a.scale = n > 0 ? 1.f / std::sqrt((float)n) : 1.f;
    std::copy(b1.begin(), b1.end(), a.h1);
    for (int i = 0; i < n; ++i)
        if (f[i] >= 0 && f[i] < V) axpy(a.h1, a.scale, &E[(size_t)f[i] * H1], H1);
    for (int i = 0; i < H1; ++i) a.h1[i] = std::max(0.f, a.h1[i]);
    for (int j = 0; j < H2; ++j) a.h2[j] = std::max(0.f, dotp(&W2[(size_t)j * H1], a.h1, H1) + b2[j]);
    float mx = -1e30f;
    for (int k = 0; k < nActive; ++k) {
        a.p[k] = dotp(&W3[(size_t)k * H2], a.h2, H2) + b3[k];
        mx = std::max(mx, a.p[k]);
    }
    float sum = 0.f;
    for (int k = 0; k < nActive; ++k) { a.p[k] = std::exp(a.p[k] - mx); sum += a.p[k]; }
    for (int k = 0; k < nActive; ++k) a.p[k] /= sum;
}
}  // namespace

void nn_init(int seed) {
    std::lock_guard<std::mutex> g(mu);
    std::mt19937 rng(seed);
    auto fill = [&](std::vector<float>& v, size_t n, float lim) {
        v.assign(n, 0.f);
        std::uniform_real_distribution<float> d(-lim, lim);
        for (auto& x : v) x = d(rng);
    };
    fill(E, (size_t)V * H1, 0.3f);
    b1.assign(H1, 0.f);
    fill(W2, (size_t)H2 * H1, std::sqrt(6.f / (H1 + H2)));
    b2.assign(H2, 0.f);
    fill(W3, (size_t)OUT * H2, std::sqrt(6.f / (H2 + OUT)));
    b3.assign(OUT, 0.f);
}

float nn_train(const int* f, int n, int nActive, int target, float lr) {
    std::lock_guard<std::mutex> g(mu);
    if (E.empty() || target < 0 || target >= nActive || nActive > OUT) return -1.f;
    Act a;
    forward(f, n, nActive, a);
    float loss = -std::log(std::max(a.p[target], 1e-7f));

    float dh2[H2] = {0}, dh1[H1] = {0};
    for (int k = 0; k < nActive; ++k) {
        float d = a.p[k] - (k == target ? 1.f : 0.f);
        float* row = &W3[(size_t)k * H2];
        axpy(dh2, d, row, H2);          // pakai bobot lama
        axpy(row, -lr * d, a.h2, H2);
        b3[k] -= lr * d;
    }
    for (int j = 0; j < H2; ++j) {
        float d = a.h2[j] > 0.f ? dh2[j] : 0.f;
        if (d == 0.f) continue;
        float* row = &W2[(size_t)j * H1];
        axpy(dh1, d, row, H1);
        axpy(row, -lr * d, a.h1, H1);
        b2[j] -= lr * d;
    }
    float dz1[H1];
    for (int i = 0; i < H1; ++i) dz1[i] = a.h1[i] > 0.f ? dh1[i] : 0.f;
    for (int i = 0; i < n; ++i)
        if (f[i] >= 0 && f[i] < V) axpy(&E[(size_t)f[i] * H1], -lr * a.scale, dz1, H1);
    axpy(b1.data(), -lr, dz1, H1);
    return loss;
}

void nn_predict(const int* f, int n, int nActive, float* out) {
    std::lock_guard<std::mutex> g(mu);
    if (E.empty() || nActive <= 0 || nActive > OUT) return;
    Act a;
    forward(f, n, nActive, a);
    for (int k = 0; k < nActive; ++k) out[k] = a.p[k];
}

static size_t total_size() { return E.size() + b1.size() + W2.size() + b2.size() + W3.size() + b3.size(); }

#ifndef NN_TEST
extern "C" {

JNIEXPORT void JNICALL Java_com_example_localai_NativeNet_nativeInit(JNIEnv*, jobject, jint seed) {
    nn_init(seed);
}

JNIEXPORT jfloat JNICALL Java_com_example_localai_NativeNet_nativeTrain(
        JNIEnv* env, jobject, jintArray feats, jint nActive, jint target, jfloat lr) {
    jsize n = env->GetArrayLength(feats);
    jint* f = env->GetIntArrayElements(feats, nullptr);
    float loss = nn_train(f, n, nActive, target, lr);
    env->ReleaseIntArrayElements(feats, f, JNI_ABORT);
    return loss;
}

JNIEXPORT void JNICALL Java_com_example_localai_NativeNet_nativePredict(
        JNIEnv* env, jobject, jintArray feats, jint nActive, jfloatArray out) {
    jsize n = env->GetArrayLength(feats);
    if (env->GetArrayLength(out) < nActive) return;
    jint* f = env->GetIntArrayElements(feats, nullptr);
    jfloat* o = env->GetFloatArrayElements(out, nullptr);
    nn_predict(f, n, nActive, o);
    env->ReleaseFloatArrayElements(out, o, 0);
    env->ReleaseIntArrayElements(feats, f, JNI_ABORT);
}

JNIEXPORT jfloatArray JNICALL Java_com_example_localai_NativeNet_nativeGetWeights(JNIEnv* env, jobject) {
    std::lock_guard<std::mutex> g(mu);
    jfloatArray arr = env->NewFloatArray((jsize)total_size());
    jsize off = 0;
    for (auto* v : {&E, &b1, &W2, &b2, &W3, &b3}) {
        env->SetFloatArrayRegion(arr, off, (jsize)v->size(), v->data());
        off += (jsize)v->size();
    }
    return arr;
}

JNIEXPORT jboolean JNICALL Java_com_example_localai_NativeNet_nativeSetWeights(
        JNIEnv* env, jobject, jfloatArray arr) {
    std::lock_guard<std::mutex> g(mu);
    if (E.empty() || (size_t)env->GetArrayLength(arr) != total_size()) return JNI_FALSE;
    jsize off = 0;
    for (auto* v : {&E, &b1, &W2, &b2, &W3, &b3}) {
        env->GetFloatArrayRegion(arr, off, (jsize)v->size(), v->data());
        off += (jsize)v->size();
    }
    return JNI_TRUE;
}

// Pin thread pemanggil ke core tertentu (mis. 2x Cortex-A76 pada Helio G99).
JNIEXPORT jint JNICALL Java_com_example_localai_NativeNet_nativeSetAffinity(
        JNIEnv* env, jobject, jintArray cpus) {
    jsize n = env->GetArrayLength(cpus);
    jint* c = env->GetIntArrayElements(cpus, nullptr);
    cpu_set_t set;
    CPU_ZERO(&set);
    for (int i = 0; i < n; ++i) if (c[i] >= 0 && c[i] < CPU_SETSIZE) CPU_SET(c[i], &set);
    env->ReleaseIntArrayElements(cpus, c, JNI_ABORT);
    return sched_setaffinity(0, sizeof(set), &set) == 0 ? 0 : -1;
}

JNIEXPORT jstring JNICALL Java_com_example_localai_NativeNet_nativeInfo(JNIEnv* env, jobject) {
#ifdef NN_NEON
    return env->NewStringUTF("NEON+FMA (aarch64)");
#else
    return env->NewStringUTF("scalar");
#endif
}
}
#endif

#ifdef NN_TEST
#include <cstdio>
int main() {
    nn_init(1);
    // 4 kelas, fitur berbeda tiap kelas; harus bisa dipelajari
    int data[4][3] = {{1,2,3},{10,11,12},{100,101,102},{500,501,502}};
    float first = 0, last = 0;
    for (int ep = 0; ep < 200; ++ep) {
        float l = 0;
        for (int c = 0; c < 4; ++c) l += nn_train(data[c], 3, 4, c, 0.1f);
        if (ep == 0) first = l;
        last = l;
    }
    float out[4];
    int ok = 0;
    for (int c = 0; c < 4; ++c) {
        nn_predict(data[c], 3, 4, out);
        int best = std::max_element(out, out + 4) - out;
        ok += (best == c);
    }
    printf("loss awal=%.3f akhir=%.3f akurasi=%d/4\n", first, last, ok);
    return (ok == 4 && last < first * 0.1f) ? 0 : 1;
}
#endif
