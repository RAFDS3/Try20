package com.example.localai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random
import java.util.concurrent.Executors

/**
 * Deep learning on-device: MLP (embedding -> 64 -> 64 -> softmax aplikasi).
 * Training berjalan di thread khusus yang dipin ke core big (Cortex-A76).
 * Experience replay mencegah model "lupa" pelajaran lama.
 */
class NeuralBrain(ctx: Context) {
    private data class Sample(val text: String, val hour: Int, val target: Int)

    private val file = File(ctx.filesDir, "net.bin")
    private val prefs = ctx.getSharedPreferences("nn", Context.MODE_PRIVATE)
    private val pkgIdx = LinkedHashMap<String, Int>()
    private val replay = ArrayList<Sample>()
    private val exec = Executors.newSingleThreadExecutor { r -> Thread(r, "nn-train") }
    private val lock = Any()

    val topology = CpuTopology.detect()
    @Volatile var ready = false
    @Volatile var lastLoss = -1f
    @Volatile var affinityOk = false
    @Volatile var trainSteps = 0L
    private var engine = "?"

    init {
        loadMeta()
        exec.execute {
            try {
                NativeNet.nativeInit(42)
                if (file.exists()) {
                    val b = ByteBuffer.wrap(file.readBytes()).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
                    val w = FloatArray(b.remaining()); b.get(w)
                    NativeNet.nativeSetWeights(w)
                }
                if (topology.big.isNotEmpty())
                    affinityOk = NativeNet.nativeSetAffinity(topology.big.toIntArray()) == 0
                engine = NativeNet.nativeInfo()
                ready = true
            } catch (e: Throwable) { engine = "gagal: ${e.message}" }
        }
    }

    private fun h(s: String) = (s.hashCode() and 0x7fffffff) % NativeNet.HASH_DIM

    /** Hash kata + trigram karakter (toleran typo) + jam. */
    fun features(text: String, hour: Int): IntArray {
        val set = HashSet<Int>()
        for (t in text.lowercase().split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }) {
            set.add(h("w:$t"))
            val p = "#$t#"
            for (i in 0..p.length - 3) set.add(h("c:" + p.substring(i, i + 3)))
        }
        set.add(NativeNet.HASH_DIM + hour)
        return set.toIntArray()
    }

    /** Probabilitas per paket, atau null jika model belum siap / terlalu sedikit data. */
    fun predict(text: String, hour: Int): Map<String, Float>? {
        if (!ready) return null
        val m: Map<String, Int>
        synchronized(lock) { if (pkgIdx.size < 3) return null; m = HashMap(pkgIdx) }
        val out = FloatArray(NativeNet.MAX_OUT)
        NativeNet.nativePredict(features(text, hour), m.size, out)
        return m.mapValues { out[it.value] }
    }

    fun nActive(): Int = synchronized(lock) { pkgIdx.size }

    fun learn(text: String, hour: Int, pkg: String) {
        if (text.isBlank()) return
        val s: Sample
        synchronized(lock) {
            if (!pkgIdx.containsKey(pkg) && pkgIdx.size >= NativeNet.MAX_OUT) return
            val t = pkgIdx.getOrPut(pkg) { pkgIdx.size }
            s = Sample(text, hour, t)
            replay.add(s)
            if (replay.size > 300) replay.removeAt(0)
        }
        exec.execute {
            if (!ready) return@execute
            val rnd = Random()
            val batch = ArrayList<Sample>()
            val nA: Int
            synchronized(lock) {
                nA = pkgIdx.size
                repeat(10) { batch.add(s) }
                repeat(20) { batch.add(replay[rnd.nextInt(replay.size)]) }
            }
            batch.shuffle()
            var loss = 0f
            for (x in batch) {
                loss = NativeNet.nativeTrain(features(x.text, x.hour), nA, x.target, 0.08f)
                trainSteps++
            }
            lastLoss = loss
            save()
        }
    }

    fun reset() {
        synchronized(lock) { pkgIdx.clear(); replay.clear() }
        exec.execute { NativeNet.nativeInit(42); save() }
    }

    fun info(): String =
        "${topology.describe()}\nNN: $engine | pin big-core: ${if (affinityOk) "ya" else "tidak"}" +
            "\nLatihan: $trainSteps langkah | loss: ${if (lastLoss < 0) "-" else "%.3f".format(lastLoss)}" +
            " | app dikenal: ${nActive()}"

    private fun save() {
        try {
            val w = NativeNet.nativeGetWeights()
            val bb = ByteBuffer.allocate(w.size * 4).order(ByteOrder.LITTLE_ENDIAN)
            bb.asFloatBuffer().put(w)
            file.writeBytes(bb.array())
            val idx = JSONObject(); val rep = JSONArray()
            synchronized(lock) {
                pkgIdx.forEach { (k, v) -> idx.put(k, v) }
                replay.forEach { rep.put(JSONArray().put(it.text).put(it.hour).put(it.target)) }
            }
            prefs.edit().putString("idx", idx.toString()).putString("replay", rep.toString()).apply()
        } catch (_: Exception) { }
    }

    private fun loadMeta() {
        try {
            val idx = JSONObject(prefs.getString("idx", "{}")!!)
            idx.keys().forEach { pkgIdx[it] = idx.getInt(it) }
            val rep = JSONArray(prefs.getString("replay", "[]")!!)
            for (i in 0 until rep.length()) {
                val a = rep.getJSONArray(i)
                replay.add(Sample(a.getString(0), a.getInt(1), a.getInt(2)))
            }
            // model & indeks harus konsisten: jika file bobot hilang, mulai bersih
            if (!file.exists()) { pkgIdx.clear(); replay.clear() }
        } catch (_: Exception) { pkgIdx.clear(); replay.clear() }
    }
}
