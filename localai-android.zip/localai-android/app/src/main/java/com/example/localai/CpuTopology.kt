package com.example.localai

import android.os.Build
import java.io.File

/** Deteksi core "big" (Helio G99: cpu6-7 = 2x Cortex-A76, cpu0-5 = 6x Cortex-A55). */
data class CpuTopology(val cores: Int, val big: List<Int>, val soc: String) {
    val isHelioG99: Boolean get() = soc.lowercase().contains("mt6789") || soc.lowercase().contains("g99")

    fun describe() = "SoC: $soc | $cores core | big: ${if (big.isEmpty()) "-" else big.joinToString(",")}"

    companion object {
        fun detect(): CpuTopology {
            val n = Runtime.getRuntime().availableProcessors()
            val freqs = (0 until n).map {
                try { File("/sys/devices/system/cpu/cpu$it/cpufreq/cpuinfo_max_freq").readText().trim().toLong() }
                catch (e: Exception) { -1L }
            }
            var big: List<Int> = emptyList()
            if (freqs.all { it > 0 }) {
                val mx = freqs.max()
                if (mx > freqs.min()) big = freqs.indices.filter { freqs[it] == mx }
            } else if (n == 8) {
                big = listOf(6, 7) // fallback layout Helio G99
            }
            val soc = if (Build.VERSION.SDK_INT >= 31)
                "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else Build.HARDWARE
            return CpuTopology(n, big, soc)
        }
    }
}
