package com.example.localai

/** Jembatan JNI ke jaringan saraf (C++ + NEON). */
object NativeNet {
    const val HASH_DIM = 1024
    const val MAX_OUT = 256

    init { System.loadLibrary("localai_native") }

    external fun nativeInit(seed: Int)
    external fun nativeTrain(feats: IntArray, nActive: Int, target: Int, lr: Float): Float
    external fun nativePredict(feats: IntArray, nActive: Int, out: FloatArray)
    external fun nativeGetWeights(): FloatArray
    external fun nativeSetWeights(w: FloatArray): Boolean
    external fun nativeSetAffinity(cpus: IntArray): Int
    external fun nativeInfo(): String
}
