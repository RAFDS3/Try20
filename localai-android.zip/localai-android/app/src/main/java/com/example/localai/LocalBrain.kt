package com.example.localai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class AppInfo(val label: String, val pkg: String)

/**
 * Otak hibrida 100% lokal:
 *  1) Heuristik + bobot kata->app (belajar cepat dari feedback)
 *  2) Jaringan saraf MLP (deep learning, C++/NEON) yang generalisasi ke kata/typo baru & kebiasaan jam
 */
class LocalBrain(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("brain", Context.MODE_PRIVATE)
    private val weights = HashMap<String, HashMap<String, Double>>()
    private val hourly = HashMap<String, IntArray>()
    val nn = NeuralBrain(ctx)

    init { load() }

    fun tokenize(s: String): List<String> =
        s.lowercase().split(Regex("[^a-z0-9]+")).filter { it.length > 1 && it !in STOP }

    private fun hourNow() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    private fun baseScore(app: AppInfo, tokens: List<String>): Double {
        val lt = tokenize(app.label)
        val low = app.label.lowercase()
        var s = 0.0
        for (t in tokens) {
            s += when {
                t in lt -> 3.0
                lt.any { it.startsWith(t) || t.startsWith(it) } -> 2.0
                low.contains(t) -> 1.5
                app.pkg.contains(t) -> 1.0
                else -> 0.0
            }
            s += weights[app.pkg]?.get(t) ?: 0.0
        }
        if (s > 0) {
            val h = hourly[app.pkg]
            if (h != null) s += 0.5 * h[hourNow()] / (h.sum() + 1.0)
        }
        return s
    }

    fun rank(command: String, apps: List<AppInfo>): List<Pair<AppInfo, Double>> {
        val tokens = tokenize(command)
        if (tokens.isEmpty()) return emptyList()
        val probs = nn.predict(tokens.joinToString(" "), hourNow())
        val n = nn.nActive().coerceAtLeast(1)
        return apps.map { app ->
            var s = baseScore(app, tokens)
            val p = probs?.get(app.pkg)
            if (p != null) s += 5.0 * (p - 1.0 / n).coerceAtLeast(0.0)  // bonus hanya jika di atas peluang acak
            app to s
        }.filter { it.second > 0.5 }.sortedByDescending { it.second }
    }

    fun learn(command: String, pkg: String, positive: Boolean) {
        val m = weights.getOrPut(pkg) { HashMap() }
        val tokens = tokenize(command)
        for (t in tokens) {
            val cur = m[t] ?: 0.0
            m[t] = (cur + if (positive) 1.5 else -1.0).coerceIn(-5.0, 10.0)
        }
        if (positive) nn.learn(tokens.joinToString(" "), hourNow(), pkg)
        save()
    }

    fun recordUse(pkg: String) {
        hourly.getOrPut(pkg) { IntArray(24) }[hourNow()]++
        save()
    }

    fun suggest(apps: List<AppInfo>, n: Int = 4): List<AppInfo> {
        val h = hourNow()
        return apps.filter { (hourly[it.pkg]?.get(h) ?: 0) > 0 }
            .sortedByDescending { hourly[it.pkg]!![h] }
            .take(n)
    }

    fun knowledgeCount() = weights.values.sumOf { it.size }

    fun info(): String = nn.info()

    fun reset() { weights.clear(); hourly.clear(); nn.reset(); save() }

    private fun save() {
        val w = JSONObject()
        weights.forEach { (p, m) -> w.put(p, JSONObject(m as Map<*, *>)) }
        val h = JSONObject()
        hourly.forEach { (p, a) -> h.put(p, JSONArray(a.toList())) }
        prefs.edit().putString("w", w.toString()).putString("h", h.toString()).apply()
    }

    private fun load() {
        try {
            JSONObject(prefs.getString("w", "{}")!!).let { w ->
                w.keys().forEach { p ->
                    val o = w.getJSONObject(p)
                    val m = HashMap<String, Double>()
                    o.keys().forEach { k -> m[k] = o.getDouble(k) }
                    weights[p] = m
                }
            }
            JSONObject(prefs.getString("h", "{}")!!).let { h ->
                h.keys().forEach { p ->
                    val a = h.getJSONArray(p)
                    hourly[p] = IntArray(24) { i -> a.optInt(i, 0) }
                }
            }
        } catch (_: Exception) { }
    }

    companion object {
        private val STOP = setOf(
            "buka", "bukakan", "tolong", "aplikasi", "app", "open", "launch", "jalankan",
            "ke", "dong", "ya", "the", "please", "saya", "mau", "aku", "yang", "dan"
        )
    }
}
