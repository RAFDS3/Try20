package com.example.localai

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*

class MainActivity : Activity() {
    private lateinit var brain: LocalBrain
    private lateinit var apps: List<AppInfo>
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var box: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        brain = LocalBrain(this)
        apps = loadApps()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }
        root.addView(TextView(this).apply { text = "Local AI"; textSize = 26f })
        input = EditText(this).apply {
            hint = "Ketik perintah, mis: buka whatsapp"
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> run(); true }
        }
        root.addView(input)
        root.addView(Button(this).apply { text = "Jalankan"; setOnClickListener { run() } })
        status = TextView(this).apply { textSize = 15f; setPadding(0, dp(8), 0, dp(8)) }
        root.addView(status)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(box) })
        setContentView(root)
        showSuggestions()
    }

    override fun onResume() { super.onResume(); if (::box.isInitialized) showSuggestions() }

    private fun loadApps(): List<AppInfo> {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun launch(app: AppInfo): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(app.pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        brain.recordUse(app.pkg)
        return true
    }

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; setOnClickListener { onClick() }
    }

    private fun run() {
        val cmd = input.text.toString().trim()
        if (cmd.isEmpty()) return
        val ranked = brain.rank(cmd, apps)
        box.removeAllViews()
        if (ranked.isEmpty()) {
            status.text = "Saya belum paham \"$cmd\". Pilih aplikasinya, saya akan belajar."
            showPicker(cmd, apps)
            return
        }
        val best = ranked.first().first
        if (!launch(best)) { status.text = "Gagal membuka ${best.label}"; return }
        status.text = "Membuka ${best.label}. Sudah benar?"
        box.addView(btn("✅ Benar") {
            brain.learn(cmd, best.pkg, true)
            status.text = "Dipelajari. Pengetahuan: ${brain.knowledgeCount()} asosiasi."
            box.removeAllViews(); showSuggestions()
        })
        box.addView(btn("❌ Salah") {
            brain.learn(cmd, best.pkg, false)
            status.text = "Oke, pilih yang benar:"
            box.removeAllViews()
            showPicker(cmd, ranked.drop(1).map { it.first }.take(5).ifEmpty { apps })
        })
    }

    private fun showPicker(cmd: String, list: List<AppInfo>) {
        list.forEach { app ->
            box.addView(btn(app.label) {
                brain.learn(cmd, app.pkg, true)
                launch(app)
                status.text = "Belajar: \"$cmd\" → ${app.label}"
                box.removeAllViews(); showSuggestions()
            })
        }
    }

    private fun showSuggestions() {
        val s = brain.suggest(apps)
        if (s.isEmpty()) return
        box.addView(TextView(this).apply { text = "Biasanya jam ini kamu buka:" })
        s.forEach { app -> box.addView(btn(app.label) { launch(app) }) }
    }
}
